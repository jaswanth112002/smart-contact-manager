# SmartContactManager
Smart Contact Manager is a web application designed to manage and organize your contacts efficiently. It provides functionalities to add, search and view contact details, ensuring a user-friendly experience.
