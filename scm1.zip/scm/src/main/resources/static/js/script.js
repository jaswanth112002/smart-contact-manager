let currentTheme = getTheme();

document.addEventListener("DOMContentLoaded", () => {
  changeTheme();
});

function changeTheme() {

  // changePageTheme(currentTheme, "");

  //set the listener to change theme button
  const changeThemeButton = document.querySelector("#theme_change_button");

  const oldTheme = currentTheme;
  changeThemeButton.addEventListener("click", (event) => {
    console.log("change theme button clicked");
    if (currentTheme === "dark") {
      currentTheme = "light";
    } else {
      currentTheme = "dark";
    }
    changePageTheme(currentTheme, oldTheme);
  });
}

//set theme to localstorage
function setTheme(theme) {
  localStorage.setItem("theme", theme);
}

//get theme from localstorage
function getTheme() {
  let theme = localStorage.getItem("theme");
  return theme ? theme : "light";
}

//change current page theme
function changePageTheme(theme, oldTheme) {
  setTheme(currentTheme);
  document.querySelector("html").classList.remove(oldTheme);
  document.querySelector("html").classList.add(theme);


  // change btn text
  document
    .querySelector("#theme_change_button")
    .querySelector("span").textContent = theme == "light" ? "Dark" : "Light";
}
