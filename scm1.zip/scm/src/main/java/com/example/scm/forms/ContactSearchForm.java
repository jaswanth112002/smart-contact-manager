package com.example.scm.forms;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactSearchForm {

    private String field;
    private String value;

}