package com.example.scm.entities;


public enum Providers {

    SELF, GOOGLE, GITHUB

}