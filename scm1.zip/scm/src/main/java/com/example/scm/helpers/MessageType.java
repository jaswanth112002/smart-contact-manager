package com.example.scm.helpers;


public enum MessageType {

    blue, red, green, yellow
}